%% --- Compute Essential Matrix ---
E = compute_essential_matrix(F, K1, K2)
disp('Estimated Essential Matrix E:');
disp(E);